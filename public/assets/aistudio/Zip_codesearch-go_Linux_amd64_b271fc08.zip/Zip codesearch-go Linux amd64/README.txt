codesearch-go — Linux x86-64, statically linked
================================================
Version : codesearch schema=go9 commit=8c5d6ffe8685 built=2026-10-31T19:05:43Z go=go1.27.3
Binary  : codesearch-go (ELF 64-bit, x86-64, statically linked, not stripped)
SHA256  : d2e3b9f3b6ee3d8a3bd9626d9f8299d968911fa4ff4bbca1ff4bb9131b8c67cc
Isi zip : codesearch-go + README.txt ini saja (bukan source code).

Cara pakai (di mesin Linux x86-64 tujuan):
  chmod +x codesearch-go
  ./codesearch-go --version
  ./codesearch-go --root <direktori-kode> <query>
  ./codesearch-go --root <direktori-kode> --once --paths-only <query>
  ./codesearch-go --root <direktori-kode> --defs-only <query>   # cari definisi, bukan use-site
  ./codesearch-go --help

Catatan:
- Biner ini HANYA untuk Linux x86-64. Bukan Windows, bukan macOS,
  bukan Android ARM64.
- Tidak butuh runtime/library tambahan (statically linked).
- Indeks cache disimpan di ~/.cache/codesearch-go/; pakai --once
  untuk indeks in-memory tanpa cache.
- Source code, harness verifikasi tokenize, dan skrip build TIDAK
  ikut di zip ini; zip ini hanya hasil build yang siap jalan.
